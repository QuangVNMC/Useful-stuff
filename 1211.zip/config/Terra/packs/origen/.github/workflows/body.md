# Download

To install the latest release, please download the origin-*.zip from the **Assets** section, and replace the current origen-*.zip in your pack folder with it.